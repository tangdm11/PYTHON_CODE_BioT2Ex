from distutils.core import setup
setup(name = "Bio_T2Ex",
      version = "1.0",
      description = "---------------",
      author = "tt",
      py_modules = [
                    "Bio_T2Ex.macs",
                    "Bio_T2Ex.mutsigcv",
                    "Bio_T2Ex.package_2_render",
                    "Bio_T2Ex.package_3_render",
                    "Bio_T2Ex.package_autowidth",
                    "Bio_T2Ex.package_sort"])

                    


